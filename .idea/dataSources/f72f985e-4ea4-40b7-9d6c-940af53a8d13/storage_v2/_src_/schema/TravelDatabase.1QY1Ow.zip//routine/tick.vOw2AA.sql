create procedure tick()
  begin
    declare done boolean default false;
    declare val smallint unsigned;
    declare i smallint unsigned;

    declare cur cursor for select id
                           from Shedule;
    declare continue handler for not found set done = true;

    open cur;

    readLoop: loop
      fetch cur
      into val;

      if done
      then leave readLoop;
      end if;


      insert into Ticket (sheduleId, class, amount, quantity) value
        (val, 'Economy', 150, 40);

      insert into Ticket (sheduleId, class, amount, quantity) value
        (val, 'Business', 300, 10);

    end loop;
  end;

